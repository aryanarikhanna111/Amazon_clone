// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyAacwKOFoLRUEJ0crtHGjtQNBldUAF_uoM",
    authDomain: "clone-a6865.firebaseapp.com",
    databaseURL: "https://clone-a6865.firebaseio.com",
    projectId: "clone-a6865",
    storageBucket: "clone-a6865.appspot.com",
    messagingSenderId: "987512157755",
    appId: "1:987512157755:web:89a3bcd713f30861200e1e",
    measurementId: "G-RF6CBW0L0Z"
  };